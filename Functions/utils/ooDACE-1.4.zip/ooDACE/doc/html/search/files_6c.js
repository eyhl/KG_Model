var searchData=
[
  ['likelihood_2em',['likelihood.m',['../likelihood_8m.html',1,'']]]
];
