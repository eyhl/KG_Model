var searchData=
[
  ['oodacefit',['oodacefit',['../oodacefit_8m.html#a539bcafbcdc32b0dfe903360759a73b1',1,'oodacefit.m']]],
  ['oodacefit_2em',['oodacefit.m',['../oodacefit_8m.html',1,'']]],
  ['optimidx',['optimIdx',['../class_basic_gaussian_process.html#a3f6f06747a894e644d9659241463651c',1,'BasicGaussianProcess']]],
  ['optimize',['optimize',['../class_matlab_g_a.html#ad53a9b1707f683766c441f96a8500411',1,'MatlabGA::optimize()'],['../class_matlab_optimizer.html#ad53a9b1707f683766c441f96a8500411',1,'MatlabOptimizer::optimize()'],['../class_optimizer.html#ad53a9b1707f683766c441f96a8500411',1,'Optimizer::optimize()'],['../class_s_q_p_lab_optimizer.html#ad53a9b1707f683766c441f96a8500411',1,'SQPLabOptimizer::optimize()']]],
  ['optimize_2em',['optimize.m',['../@_matlab_optimizer_2optimize_8m.html',1,'']]],
  ['optimize_2em',['optimize.m',['../@_optimizer_2optimize_8m.html',1,'']]],
  ['optimize_2em',['optimize.m',['../@_s_q_p_lab_optimizer_2optimize_8m.html',1,'']]],
  ['optimize_2em',['optimize.m',['../@_matlab_g_a_2optimize_8m.html',1,'']]],
  ['optimizer',['Optimizer',['../class_optimizer.html',1,'Optimizer'],['../class_optimizer.html#a4ceb3a8a1f085553624d7c96670dcf76',1,'Optimizer::Optimizer()']]],
  ['optimizer_2em',['Optimizer.m',['../_optimizer_8m.html',1,'']]],
  ['optimnrparameters',['optimNrParameters',['../class_basic_gaussian_process.html#a0c10d8e65ed04a6dd47b9c8fa1fd40b9',1,'BasicGaussianProcess']]],
  ['options',['options',['../class_basic_gaussian_process.html#a0717e747985fb4e7eb9a3cdc4f1426bf',1,'BasicGaussianProcess']]]
];
