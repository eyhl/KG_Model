var searchData=
[
  ['fit',['fit',['../class_basic_gaussian_process.html#a5289e400652af63e9d55ac2eed917684',1,'BasicGaussianProcess::fit()'],['../class_blind_kriging.html#a5289e400652af63e9d55ac2eed917684',1,'BlindKriging::fit()'],['../class_co_kriging.html#a5289e400652af63e9d55ac2eed917684',1,'CoKriging::fit()']]],
  ['fit_2em',['fit.m',['../@_basic_gaussian_process_2fit_8m.html',1,'']]],
  ['fit_2em',['fit.m',['../@_blind_kriging_2fit_8m.html',1,'']]],
  ['fit_2em',['fit.m',['../@_co_kriging_2fit_8m.html',1,'']]],
  ['ft',['Ft',['../class_basic_gaussian_process.html#a0cb3f9e3fcef602adbab963356fbb226',1,'BasicGaussianProcess']]],
  ['ft_5freinterp',['Ft_reinterp',['../class_basic_gaussian_process.html#a98f8f8abbf53821e1a08ad0c2e95876a',1,'BasicGaussianProcess']]]
];
