var searchData=
[
  ['mainpage_2em',['mainpage.m',['../mainpage_8m.html',1,'']]],
  ['makeevalgrid_2em',['makeEvalGrid.m',['../make_eval_grid_8m.html',1,'']]],
  ['makegrid_2em',['makeGrid.m',['../make_grid_8m.html',1,'']]],
  ['marginallikelihood_2em',['marginalLikelihood.m',['../marginal_likelihood_8m.html',1,'']]],
  ['matlabga_2em',['MatlabGA.m',['../_matlab_g_a_8m.html',1,'']]],
  ['matlaboptimizer_2em',['MatlabOptimizer.m',['../_matlab_optimizer_8m.html',1,'']]],
  ['mergestruct_2em',['mergeStruct.m',['../merge_struct_8m.html',1,'']]],
  ['msetestset_2em',['mseTestset.m',['../mse_testset_8m.html',1,'']]]
];
