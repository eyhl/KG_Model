var searchData=
[
  ['makeevalgrid',['makeEvalGrid',['../make_eval_grid_8m.html#a0fe94e6c1b0b77b26c64271cfbe92662',1,'makeEvalGrid.m']]],
  ['makegrid',['makeGrid',['../make_grid_8m.html#afc538f5808c3ba8424cb849f23c582e1',1,'makeGrid.m']]],
  ['marginallikelihood',['marginalLikelihood',['../class_basic_gaussian_process.html#abdae81924429de5771589a7b939a4580',1,'BasicGaussianProcess']]],
  ['matlabga',['MatlabGA',['../class_matlab_g_a.html#a6cd991a5366d217109da90f39891b781',1,'MatlabGA']]],
  ['matlaboptimizer',['MatlabOptimizer',['../class_matlab_optimizer.html#add0981dbfbab6e73c1e10da29688978f',1,'MatlabOptimizer']]],
  ['mergestruct',['mergeStruct',['../merge_struct_8m.html#ac299e8f8ade62effc55cd0d3b54ea234',1,'mergeStruct.m']]],
  ['msetestset',['mseTestset',['../class_basic_gaussian_process.html#a32b50de60e0f68b9958f77c537825724',1,'BasicGaussianProcess']]]
];
