var searchData=
[
  ['kriging_2em',['Kriging.m',['../_kriging_8m.html',1,'']]]
];
