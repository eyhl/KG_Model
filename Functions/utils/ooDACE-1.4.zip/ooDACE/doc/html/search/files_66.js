var searchData=
[
  ['fit_2em',['fit.m',['../@_basic_gaussian_process_2fit_8m.html',1,'']]],
  ['fit_2em',['fit.m',['../@_co_kriging_2fit_8m.html',1,'']]],
  ['fit_2em',['fit.m',['../@_blind_kriging_2fit_8m.html',1,'']]]
];
